from behave import given, when, then
from selenium import webdriver
from selenium.webdriver.common.by import By


@given('launch chrome browser')
def launchBrowser(context):
    #context.driver = webdriver.Chrome(executable_path="E:\\New folder\\behaveProject\chromedriver.exe")
    context.driver = webdriver.Chrome()
    # the path is added into pycharm
    # this is a good practice.
    # context.driver = webdriver.Chrome()


@when('open orange HRM homepage')
def openHomePage(context):
    context.driver.get("https://opensource-demo.orangehrmlive.com/")


@then('verify that the logo present on page')
def verifyLogo(context):
    # .is_displayed() will give boolean result which we are storing in status (ie.True)
    status =  context.driver.find_element(By.XPATH,"//div[@id='divLogo']//img").is_displayed()
    assert status is True


@then('close browser')
def closeBrowser(context):
    context.driver.close()

