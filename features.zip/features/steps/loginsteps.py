import behave
from selenium import webdriver
from selenium.webdriver.common.by import By


@behave.given('I launch chrome browser')
def launch(context):
    context.driver = webdriver.Chrome()

@behave.when('I open OrangeHRM home page')
def step_impl(context):
    context.driver.get("https://opensource-demo.orangehrmlive.com/index.php/auth/login")


@behave.when('Enter user name "{user}" & password "{pswd}"')
def credential(context, user, pswd):
    context.driver.find_element(By.ID,"txtUsername").send_keys(user)
    context.driver.find_element(By.ID,"txtPassword").send_keys(pswd)


@behave.when(u'click on login button')
def loginButton(context):
    context.driver.find_element(By.XPATH,"//input[@id='btnLogin']").click()


@behave.then(u'User must Successfully login to Dashboard page')
def homepage(context):
    Text = context.driver.find_element(By.XPATH,"//h1[normalize-space()='Dashboard']").text
    assert Text=="Dashboard"
    context.driver.close()
